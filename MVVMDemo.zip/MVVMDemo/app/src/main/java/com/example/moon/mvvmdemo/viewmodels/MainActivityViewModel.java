package com.example.moon.mvvmdemo.viewmodels;

public class MainActivityViewModel {

}
