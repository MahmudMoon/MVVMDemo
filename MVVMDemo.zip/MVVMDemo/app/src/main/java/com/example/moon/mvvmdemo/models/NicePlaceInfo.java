package com.example.moon.mvvmdemo.models;

public class NicePlaceInfo {
}
