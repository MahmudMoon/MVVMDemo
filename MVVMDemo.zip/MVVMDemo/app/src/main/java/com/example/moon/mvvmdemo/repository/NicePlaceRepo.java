package com.example.moon.mvvmdemo.repository;

public class NicePlaceRepo {
}
